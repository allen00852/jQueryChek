(function($) {
  /**
   * @param {$allCheck} th下面的input
   * @param {$checks} td下面所以的input
   * @param {$check_array} checkbox value值 数据为数组
   * @param {options.AllDele} 获取数据的按钮
   */
  $.fn.chek = function(options) {
    var $allCheck = $(this)
      .find("th")
      .find(":checkbox");
    var $checks = $(this)
      .find("td")
      .find(":checkbox");
    var $check_array = [];
    $allCheck.on("click", function() {
      $checks.prop("checked", $(this).prop("checked"));
    });
    $checks.on("click", function() {
      $allCheck.prop(
        "checked",
        $checks.length ===
          $(this)
            .parents("tbody")
            .find("input:checked").length
      );
    });
    $(options.AllDele).on("click", function() {
      $check_array = [];
      $checks.each(function() {
        if ($(this).prop("checked") != false) $check_array.push($(this).val());
      });
      $.ajax({
        type: "post",
        async: false,
        url: options.url,
        traditional: true,
        data: { data: JSON.stringify($check_array) },
        success: function(data) {
          if (data !== 0) {
            console.log(data);
          } else {
            alert("no data");
          }
        },
        error: function(data) {}
      });
    });
  };
})(jQuery);
